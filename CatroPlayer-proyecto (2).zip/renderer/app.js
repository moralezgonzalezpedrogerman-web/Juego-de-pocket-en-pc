// Pantalla de inicio: detecta el juego junto al .exe o deja elegirlo.
(function () {
  const ui = document.getElementById('ui'), msg = document.getElementById('msg');
  const setMsg = t => { msg.textContent = t; };
  window.api.onProgress(p => setMsg('Descomprimiendo juego (solo la primera vez)… ' + p + '%'));

  async function launch(res) {
    if (!res) return false;
    if (res.error) { setMsg('Error: ' + res.error); return false; }
    ui.style.display = 'none';
    try { await CatroEngine.start(res, window.api); }
    catch (e) { console.error(e); ui.style.display = 'flex'; setMsg('Error: ' + e.message); return false; }
    return true;
  }
  async function choose(kind) {
    setMsg('Abriendo…');
    const res = await window.api.pick(kind);
    if (!res) { setMsg(''); return; }
    await launch(res);
  }
  document.getElementById('bFile').onclick = () => choose('file');
  document.getElementById('bFolder').onclick = () => choose('folder');
  window.api.lastGame().then(g => {
    if (!g) return; const b = document.getElementById('bLast');
    b.textContent = '▶ Continuar: ' + g.name; b.style.display = '';
    b.onclick = async () => { setMsg('Abriendo…'); await launch(await window.api.openPath(g.path)); };
  });
  setMsg('Buscando juego junto al .exe…');
  window.api.autoDetect().then(async r => { if (!(await launch(r))) { if (!r) setMsg(''); } });
})();
