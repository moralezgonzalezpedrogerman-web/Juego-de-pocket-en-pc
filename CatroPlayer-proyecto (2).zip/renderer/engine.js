'use strict';
// CatroEngine: lee el code.xml de un proyecto Catrobat/Pocket Code y lo ejecuta en un canvas.
(function () {
  const STOP = Symbol('stop');
  const G = {
    api: null, src: null, doc: null, W: 2400, H: 1080,
    scenes: [], sceneName: '', sprites: [], vars: {}, saved: {},
    touch: { down: false, x: 0, y: 0 }, now: 0, waiters: [], videos: {}, sounds: {},
    texts: {}, pending: null, loading: false, unknown: {}, conds: [], runs: new Set(), t0: 0
  };

  const seen = new Set();
  function warn(msg) { // avisa en consola y guarda en el registro (una sola vez por mensaje)
    if (seen.has(msg)) return; seen.add(msg); console.warn(msg);
    try { G.api.log && G.api.log(msg); } catch (e) {}
  }

  // ---------- utilidades XML ----------
  const kids = (el, tag) => el ? Array.from(el.children).filter(c => c.tagName === tag) : [];
  const kid = (el, tag) => el ? Array.from(el.children).find(c => c.tagName === tag) || null : null;
  const txt = (el, tag) => { const k = kid(el, tag); return k ? k.textContent : ''; };

  // Resuelve referencias relativas estilo XStream ("../../soundList/sound[2]")
  function resolveRef(el, ref) {
    let cur = el;
    for (const part of ref.split('/')) {
      if (part === '..') cur = cur.parentElement;
      else if (part === '.' || part === '') continue;
      else {
        const m = part.match(/^([^\[]+)(?:\[(\d+)\])?$/);
        const n = m[2] ? +m[2] : 1; let c = 0, found = null;
        for (const ch of cur.children) if (ch.tagName === m[1] && ++c === n) { found = ch; break; }
        cur = found;
      }
      if (!cur) return null;
    }
    return cur;
  }
  function deref(el) {
    let guard = 0;
    while (el && el.getAttribute('reference') && guard++ < 20) el = resolveRef(el, el.getAttribute('reference'));
    return el;
  }
  function varName(el) { // el = <userVariable> (inline o con reference)
    const r = deref(el);
    if (!r) return null;
    const n = r.getElementsByTagName('name')[0] || r.getElementsByTagName('n')[0];
    return n ? n.textContent : null;
  }

  function varKey(el) { // clave de guardado en el dispositivo (deviceValueKey)
    const r = deref(el); if (!r) return null;
    const k = r.getElementsByTagName('deviceValueKey')[0];
    return k ? k.textContent : null;
  }

  // ---------- compilación ----------
  function compF(el) {
    if (!el) return null;
    return { type: txt(el, 'type'), value: txt(el, 'value'), l: compF(kid(el, 'leftChild')), r: compF(kid(el, 'rightChild')) };
  }
  function compBricks(listEl) {
    const out = [];
    if (!listEl) return out;
    for (const b of listEl.children) {
      if (!b.getAttribute('type') || !(b.tagName === 'brick' || b.tagName.indexOf('.bricks.') >= 0)) continue;
      const c = compBrick(b); if (c) out.push(c);
    }
    return out;
  }
  function compBrick(b) {
    if (txt(b, 'commentedOut') === 'true') return null;
    const o = { type: b.getAttribute('type'), f: {} };
    for (const f of kids(kid(b, 'formulaList'), 'formula')) o.f[f.getAttribute('category')] = compF(f);
    const lp = kid(b, 'loopBricks'); if (lp) o.loop = compBricks(lp);
    const ib = kid(b, 'ifBranchBricks'); if (ib) o.ifB = compBricks(ib);
    const eb = kid(b, 'elseBranchBricks'); if (eb) o.elseB = compBricks(eb);
    o.msg = txt(b, 'broadcastMessage');
    o.scene = txt(b, 'sceneForTransition') || txt(b, 'sceneToStart');
    const lk = kid(b, 'look'); if (lk) o.lookEl = deref(lk);
    const sd = kid(b, 'sound'); if (sd) { const s = deref(sd); if (s) o.sound = s.getAttribute('fileName'); }
    const uv = kid(b, 'userVariable'); if (uv) { o.varName = varName(uv); o.varKey = varKey(uv); }
    const sp = kid(b, 'spinnerSelection'); if (sp) o.spinner = parseInt(sp.textContent, 10);
    const ps = kid(b, 'propertySelection'); if (ps) o.prop = parseInt(ps.textContent, 10);
    return o;
  }
  function compScene(el) {
    const name = txt(el, 'name') || txt(el, 'n');
    const objs = [];
    for (const oe of kids(kid(el, 'objectList'), 'object')) {
      const od = { name: oe.getAttribute('name'), looks: [], sounds: [], scripts: [] };
      for (const l of kids(kid(oe, 'lookList'), 'look')) od.looks.push({ file: l.getAttribute('fileName'), name: l.getAttribute('name'), el: l });
      for (const s of kids(kid(oe, 'soundList'), 'sound')) od.sounds.push({ file: s.getAttribute('fileName'), name: s.getAttribute('name') });
      for (const se of kids(kid(oe, 'scriptList'), 'script')) {
        if (txt(se, 'commentedOut') === 'true') continue;
        const sd = { type: se.getAttribute('type'), msg: txt(se, 'receivedMessage'), bricks: compBricks(kid(se, 'brickList')) };
        if (sd.type === 'WhenConditionScript') sd.cond = compF(kid(kid(se, 'formulaMap'), 'formula'));
        od.scripts.push(sd);
      }
      objs.push(od);
    }
    return { name, objs };
  }

  // ---------- fórmulas ----------
  const num = v => { if (typeof v === 'number') return v; if (typeof v === 'boolean') return v ? 1 : 0; const n = parseFloat(v); return isNaN(n) ? 0 : n; };
  const isNumLike = v => typeof v === 'number' || (typeof v === 'string' && v.trim() !== '' && !isNaN(Number(v)));
  const truthy = v => num(v) !== 0;
  function ev(f, sp) {
    if (!f) return 0;
    switch (f.type) {
      case 'NUMBER': return num(f.value);
      case 'STRING': return f.value || '';
      case 'USER_VARIABLE': return G.vars[f.value] !== undefined ? G.vars[f.value] : 0;
      case 'BRACKET': return ev(f.r, sp);
      case 'COLLISION_FORMULA': return collidesWithName(sp, f.value) ? 1 : 0;
      case 'SENSOR': return sensor(f.value, sp);
      case 'FUNCTION': return fn(f, sp);
      case 'OPERATOR': return op(f, sp);
    }
    return 0;
  }
  function op(f, sp) {
    const a = () => ev(f.l, sp), b = () => ev(f.r, sp);
    switch (f.value) {
      case 'PLUS': return num(a()) + num(b());
      case 'MINUS': return f.l ? num(a()) - num(b()) : -num(b());
      case 'MULT': return num(a()) * num(b());
      case 'DIVIDE': return num(a()) / num(b());
      case 'MOD': { const x = num(a()), y = num(b()); return y === 0 ? 0 : ((x % y) + y) % y; }
      case 'POW': return Math.pow(num(a()), num(b()));
      case 'EQUAL': case 'NOT_EQUAL': {
        const x = a(), y = b(); const eq = (isNumLike(x) && isNumLike(y)) ? num(x) === num(y) : String(x) === String(y);
        return (f.value === 'EQUAL') === eq ? 1 : 0;
      }
      case 'SMALLER_THAN': return num(a()) < num(b()) ? 1 : 0;
      case 'SMALLER_OR_EQUAL': return num(a()) <= num(b()) ? 1 : 0;
      case 'GREATER_THAN': return num(a()) > num(b()) ? 1 : 0;
      case 'GREATER_OR_EQUAL': return num(a()) >= num(b()) ? 1 : 0;
      case 'LOGICAL_AND': return truthy(a()) && truthy(b()) ? 1 : 0;
      case 'LOGICAL_OR': return truthy(a()) || truthy(b()) ? 1 : 0;
      case 'LOGICAL_NOT': return truthy(b()) ? 0 : 1;
    }
    return 0;
  }
  function fn(f, sp) {
    const a = () => ev(f.l, sp), b = () => ev(f.r, sp);
    switch (f.value) {
      case 'TRUE': return 1; case 'FALSE': return 0;
      case 'RAND': {
        const x = num(a()), y = num(b()), lo = Math.min(x, y), hi = Math.max(x, y);
        return (Number.isInteger(x) && Number.isInteger(y)) ? Math.floor(Math.random() * (hi - lo + 1)) + lo : lo + Math.random() * (hi - lo);
      }
      case 'ABS': return Math.abs(num(a())); case 'ROUND': return Math.round(num(a()));
      case 'FLOOR': return Math.floor(num(a())); case 'CEIL': return Math.ceil(num(a()));
      case 'SQRT': return Math.sqrt(num(a()));
      case 'SIN': return Math.sin(num(a()) * Math.PI / 180); case 'COS': return Math.cos(num(a()) * Math.PI / 180);
      case 'MAX': return Math.max(num(a()), num(b())); case 'MIN': return Math.min(num(a()), num(b()));
      case 'JOIN': return String(a()) + String(b());
      case 'LENGTH': return String(a()).length;
    }
    return 0;
  }
  function sensor(name, sp) {
    switch (name) {
      case 'FINGER_TOUCHED': return G.touch.down ? 1 : 0;
      case 'FINGER_X': return G.touch.x; case 'FINGER_Y': return G.touch.y;
      case 'COLLIDES_WITH_FINGER': return G.touch.down && sp && hit(sp, G.touch.x, G.touch.y) ? 1 : 0;
      case 'OBJECT_X': return sp ? sp.x : 0; case 'OBJECT_Y': return sp ? sp.y : 0;
      case 'OBJECT_SIZE': return sp ? sp.size : 100; case 'OBJECT_TRANSPARENCY': return sp ? sp.trans : 0;
      case 'OBJECT_BRIGHTNESS': return sp ? sp.bright : 100; case 'OBJECT_ANGLE': case 'OBJECT_DIRECTION': return sp ? sp.dir : 90;
      case 'OBJECT_LOOK_NUMBER': return sp ? sp.lookIdx + 1 : 0;
      case 'TIMER': return (G.now - G.t0) / 1000;
    }
    return 0; // sensores de móvil (GPS, acelerómetro, etc.)
  }

  // ---------- ejecución ----------
  const chk = r => { if (r.dead) throw STOP; };
  function sleep(ms, r) { return new Promise(res => G.waiters.push({ t: G.now + ms, res })).then(() => chk(r)); }
  const frame = r => sleep(0, r);

  async function runList(list, r) { for (const b of list) await exec(b, r); }

  async function exec(b, r) {
    chk(r);
    const sp = r.sprite, F = (k) => ev(b.f[k], sp);
    switch (b.type) {
      // movimiento / apariencia
      case 'PlaceAtBrick': sp.x = num(F('X_POSITION')); sp.y = num(F('Y_POSITION')); break;
      case 'SetXBrick': sp.x = num(F('X_POSITION')); break;
      case 'SetYBrick': sp.y = num(F('Y_POSITION')); break;
      case 'ChangeXByNBrick': sp.x += num(F('X_POSITION_CHANGE')); break;
      case 'ChangeYByNBrick': sp.y += num(F('Y_POSITION_CHANGE')); break;
      case 'PointInDirectionBrick': sp.dir = num(F('DEGREES')); break;
      case 'SetSizeToBrick': sp.size = Math.max(0, num(F('SIZE'))); break;
      case 'ChangeSizeByNBrick': sp.size = Math.max(0, sp.size + num(F('SIZE_CHANGE'))); break;
      case 'SetTransparencyBrick': sp.trans = num(F('TRANSPARENCY')); break;
      case 'ChangeTransparencyByNBrick': sp.trans += num(F('TRANSPARENCY_CHANGE')); break;
      case 'SetBrightnessBrick': sp.bright = num(F('BRIGHTNESS')); break;
      case 'ChangeBrightnessByNBrick': sp.bright += num(F('BRIGHTNESS_CHANGE')); break;
      case 'ShowBrick': sp.visible = true; break;
      case 'HideBrick': sp.visible = false; break;
      case 'NextLookBrick': if (sp.looks.length) sp.lookIdx = (sp.lookIdx + 1) % sp.looks.length; break;
      case 'PreviousLookBrick': if (sp.looks.length) sp.lookIdx = (sp.lookIdx - 1 + sp.looks.length) % sp.looks.length; break;
      case 'SetLookByIndexBrick': { const i = Math.floor(num(F('LOOK_INDEX'))) - 1; if (i >= 0 && i < sp.looks.length) sp.lookIdx = i; break; }
      case 'SetLookBrick': setLook(sp, b); break;
      case 'SetBackgroundBrick': setLook(G.sprites[0], b); break;
      case 'GlideToBrick': {
        const dur = num(F('DURATION_IN_SECONDS')) * 1000, dx = num(F('X_DESTINATION')), dy = num(F('Y_DESTINATION'));
        const sx = sp.x, sy = sp.y, t0 = G.now;
        while (G.now - t0 < dur) { await frame(r); const p = Math.min(1, (G.now - t0) / dur); sp.x = sx + (dx - sx) * p; sp.y = sy + (dy - sy) * p; }
        sp.x = dx; sp.y = dy; break;
      }
      // control
      case 'WaitBrick': await sleep(num(F('TIME_TO_WAIT_IN_SECONDS')) * 1000, r); break;
      case 'WaitUntilBrick': while (!truthy(F('IF_CONDITION'))) await frame(r); break;
      case 'ForeverBrick': for (;;) { await runList(b.loop || [], r); await frame(r); } 
      case 'RepeatBrick': { const n = Math.floor(num(F('TIMES_TO_REPEAT'))); for (let i = 0; i < n; i++) { await runList(b.loop || [], r); await frame(r); } break; }
      case 'RepeatUntilBrick': while (!truthy(F('REPEAT_UNTIL_CONDITION'))) { await runList(b.loop || [], r); await frame(r); } break;
      case 'IfLogicBeginBrick': await runList(truthy(F('IF_CONDITION')) ? (b.ifB || []) : (b.elseB || []), r); break;
      case 'IfThenLogicBeginBrick': if (truthy(F('IF_CONDITION'))) await runList(b.ifB || [], r); break;
      case 'BroadcastBrick': broadcast(b.msg); break;
      case 'StopScriptBrick': {
        if (b.spinner === 2) { for (const s of sp.scripts) if (s.cur && s.cur !== r) s.cur.dead = true; }
        else if (b.spinner === 1) { for (const r2 of G.runs) r2.dead = true; throw STOP; }
        else throw STOP;
        break;
      }
      case 'SceneTransitionBrick': case 'SceneStartBrick': requestScene(b.scene); throw STOP;
      case 'ClearSceneBrick': break; // limpiar otra escena: aquí cada escena arranca de cero y la anterior se detiene al cambiar
      case 'ExitStageBrick': G.api.quit(); throw STOP;
      // variables
      case 'SetVariableBrick': if (b.varName != null) G.vars[b.varName] = F('VARIABLE'); break;
      case 'ChangeVariableBrick': if (b.varName != null) G.vars[b.varName] = num(G.vars[b.varName]) + num(F('VARIABLE_CHANGE')); break;
      case 'ShowTextBrick': if (b.varName != null) G.texts[b.varName] = { x: num(F('X_POSITION')), y: num(F('Y_POSITION')) }; break;
      case 'HideTextBrick': if (b.varName != null) delete G.texts[b.varName]; break;
      case 'WriteVariableOnDeviceBrick': if (b.varName != null) { G.saved[b.varKey || b.varName] = num(G.vars[b.varName]); G.api.saveVars(G.saved); } break;
      case 'ReadVariableFromDeviceBrick': { const k = b.varKey || b.varName; if (b.varName != null && G.saved[k] !== undefined) G.vars[b.varName] = G.saved[k]; break; }
      // sonido
      case 'PlaySoundBrick': playSound(b.sound, 0); break;
      case 'PlaySoundAtBrick': playSound(b.sound, num(F('PLAY_SOUND_AT'))); break;
      case 'PlaySoundAndWaitBrick': { const a = playSound(b.sound, 0); if (a) await new Promise(res => { a.onended = res; a.onerror = res; a.onpause = () => { if (a.ended || a.currentTime === 0 || r.dead) res(); }; setTimeout(res, 600000); }); chk(r); break; }
      case 'StopSoundBrick': { const a = G.sounds[b.sound]; if (a) { a.pause(); a.currentTime = 0; } break; }
      case 'StopAllSoundsBrick': stopAllSounds(); break;
      // video (vistas nativas)
      case 'CreateVideoBrick': createVideo(b, sp); break;
      case 'DeleteWebBrick': { const n = String(F('NAME')).trim(); const v = G.videos[n]; if (v) { v.pause(); v.remove(); delete G.videos[n]; } break; }
      case 'PlayVideoBrick': { const v = G.videos[String(F('NAME')).trim()]; if (v) v.play().catch(() => {}); break; }
      case 'PauseVideoBrick': { const v = G.videos[String(F('NAME')).trim()]; if (v) v.pause(); break; }
      case 'NativeViewConfigBrick': { // supuesto: propiedad 1 = opacidad (VALUE_2) de la vista VALUE_1
        const v = G.videos[String(ev(b.f.VALUE_1, sp)).trim()]; if (v && b.prop === 1) v.style.opacity = String(num(ev(b.f.VALUE_2, sp))); break;
      }
      // móvil: sin equivalente en PC
      case 'VibrationBrick': break;
      case 'OpenUrlBrick': G.api.openUrl(String(F('OPEN_URL'))); break;
      default: if (!G.unknown[b.type]) { G.unknown[b.type] = 1; warn('Bloque no soportado: ' + b.type); }
    }
  }
  function setLook(sp, b) {
    if (!sp || !b.lookEl) return;
    let i = sp.looks.findIndex(l => l.el === b.lookEl);
    if (i < 0) { const fn = b.lookEl.getAttribute('fileName'); i = sp.looks.findIndex(l => l.file === fn); }
    if (i >= 0) sp.lookIdx = i;
  }

  // ---------- scripts ----------
  function startScript(s) {
    if (s.cur) s.cur.dead = true;
    const r = { dead: false, sprite: s.sprite }; s.cur = r; G.runs.add(r);
    (async () => {
      try { await runList(s.def.bricks, r); }
      catch (e) { if (e !== STOP) { console.error(e); warn('Error en script de ' + s.sprite.name + ': ' + (e && e.message)); } }
      finally { G.runs.delete(r); }
    })();
  }
  function broadcast(msg) {
    for (const sp of G.sprites) for (const s of sp.scripts) if (s.def.type === 'BroadcastScript' && s.def.msg === msg) startScript(s);
  }

  // ---------- sprites, dibujo y toques ----------
  function makeSprite(od, sceneName) {
    const sp = { name: od.name, x: 0, y: 0, size: 100, dir: 90, visible: true, trans: 0, bright: 100, lookIdx: 0, scripts: [], looks: [], od };
    for (const l of od.looks) sp.looks.push({ file: l.file, name: l.name, el: l.el, img: null });
    for (const d of od.scripts) sp.scripts.push({ def: d, sprite: sp, cur: null, prev: false });
    return sp;
  }
  function findFile(name, sceneName) {
    const list = G.src.index[String(name).toLowerCase()];
    if (!list || !list.length) return null;
    const sn = sceneName.toLowerCase();
    return list.find(p => p.toLowerCase().split(/[\\/]/).includes(sn)) || list[0];
  }
  function loadImg(file, sceneName) {
    return new Promise(res => {
      const p = findFile(file, sceneName);
      if (!p) { warn('Falta imagen: ' + file); return res(null); }
      const im = new Image(); im.onload = () => res(im); im.onerror = () => { warn('No se pudo cargar: ' + p); res(null); };
      im.src = G.api.fileUrl(p);
    });
  }
  const cur = sp => sp.looks[sp.lookIdx] || null;
  const px = document.createElement('canvas'); px.width = px.height = 1;
  const pxc = px.getContext('2d', { willReadFrequently: true });
  function hit(sp, x, y) {
    if (!sp.visible) return false;
    const l = cur(sp); if (!l || !l.img || sp.size <= 0) return false;
    const dx = x - sp.x, dy = -(y - sp.y); // y de pantalla (hacia abajo)
    const a = (sp.dir - 90) * Math.PI / 180, c = Math.cos(-a), s = Math.sin(-a);
    const lx = (dx * c - dy * s) / (sp.size / 100) + l.img.naturalWidth / 2;
    const ly = (dx * s + dy * c) / (sp.size / 100) + l.img.naturalHeight / 2;
    if (lx < 0 || ly < 0 || lx >= l.img.naturalWidth || ly >= l.img.naturalHeight) return false;
    try { pxc.clearRect(0, 0, 1, 1); pxc.drawImage(l.img, Math.floor(lx), Math.floor(ly), 1, 1, 0, 0, 1, 1); return pxc.getImageData(0, 0, 1, 1).data[3] > 0; }
    catch { return true; }
  }
  function tap(x, y) {
    // Como Catroid: el objeto más alto que reciba el toque y tenga bloque "al tocar" lo atiende;
    // si no lo tiene, el toque pasa al objeto de abajo.
    for (let i = G.sprites.length - 1; i >= 0; i--) {
      const sp = G.sprites[i], ss = sp.scripts.filter(s => s.def.type === 'WhenScript');
      if (ss.length && hit(sp, x, y)) { for (const s of ss) startScript(s); return; }
    }
  }
  // Máscara de transparencia reducida (máx. 128 px) para colisiones rápidas
  function maskOf(l) {
    if (l.mask !== undefined) return l.mask;
    if (!l.img) return null;
    const iw = l.img.naturalWidth, ih = l.img.naturalHeight, k = Math.max(1, Math.max(iw, ih) / 128);
    const w = Math.max(1, Math.round(iw / k)), h = Math.max(1, Math.round(ih / k));
    try {
      const c = document.createElement('canvas'); c.width = w; c.height = h;
      const x = c.getContext('2d', { willReadFrequently: true }); x.drawImage(l.img, 0, 0, w, h);
      const d = x.getImageData(0, 0, w, h).data, a = new Uint8Array(w * h), cells = [];
      for (let i = 0; i < w * h; i++) if (d[i * 4 + 3] > 10) { a[i] = 1; cells.push(i); }
      l.mask = { w, h, a, cells, iw, ih };
    } catch (e) { l.mask = null; }
    return l.mask;
  }
  function collides(A, B) {
    if (A === B || A.size <= 0 || B.size <= 0) return false;
    if (!A.visible || !B.visible || A.trans >= 100 || B.trans >= 100) return false; // ocultos o 100 % transparentes no colisionan
    const la = cur(A), lb = cur(B); if (!la || !lb || !la.img || !lb.img) return false;
    const ra = Math.hypot(la.img.naturalWidth, la.img.naturalHeight) / 2 * A.size / 100;
    const rb = Math.hypot(lb.img.naturalWidth, lb.img.naturalHeight) / 2 * B.size / 100;
    if (Math.hypot(A.x - B.x, A.y - B.y) > ra + rb) return false;
    const ma = maskOf(la), mb = maskOf(lb); if (!ma || !mb) return true;
    const aa = (A.dir - 90) * Math.PI / 180, ca = Math.cos(aa), sa = Math.sin(aa);
    const ab = -(B.dir - 90) * Math.PI / 180, cb = Math.cos(ab), sb = Math.sin(ab);
    const sA = A.size / 100, sB = B.size / 100, stride = Math.max(1, Math.ceil(ma.cells.length / 3000));
    for (let n = 0; n < ma.cells.length; n += stride) {
      const c = ma.cells[n], ix = c % ma.w, iy = (c / ma.w) | 0;
      const px = ((ix + 0.5) / ma.w - 0.5) * ma.iw * sA, py = ((iy + 0.5) / ma.h - 0.5) * ma.ih * sA;
      const x = A.x + px * ca - py * sa, y = A.y - (px * sa + py * ca);     // posición en el escenario
      const dx = x - B.x, dy = -(y - B.y);
      const lx = (dx * cb - dy * sb) / sB / mb.iw * mb.w + mb.w / 2, ly = (dx * sb + dy * cb) / sB / mb.ih * mb.h + mb.h / 2;
      if (lx >= 0 && ly >= 0 && lx < mb.w && ly < mb.h && mb.a[(ly | 0) * mb.w + (lx | 0)]) return true;
    }
    return false;
  }
  function collidesWithName(sp, name) {
    if (!sp) return false;
    const n = String(name).replace(/\s*\(collision\)\s*$/i, '');
    let found = G.sprites.filter(o => o.name === n);
    if (!found.length) found = G.sprites.filter(o => o.name.trim() === n.trim());
    for (const o of found) if (collides(sp, o)) return true;
    return false;
  }
  let ctx, canvas;
  function draw() {
    ctx.clearRect(0, 0, G.W, G.H); ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, G.W, G.H);
    for (const sp of G.sprites) {
      if (!sp.visible) continue; const l = cur(sp); if (!l || !l.img) continue;
      const alpha = 1 - sp.trans / 100; if (alpha <= 0 || sp.size <= 0) continue;
      ctx.save();
      ctx.translate(G.W / 2 + sp.x, G.H / 2 - sp.y); ctx.rotate((sp.dir - 90) * Math.PI / 180);
      const s = sp.size / 100; ctx.scale(s, s); ctx.globalAlpha = Math.min(1, alpha);
      if (sp.bright !== 100) ctx.filter = 'brightness(' + Math.max(0, sp.bright) + '%)';
      ctx.drawImage(l.img, -l.img.naturalWidth / 2, -l.img.naturalHeight / 2);
      ctx.restore();
    }
    ctx.font = 'bold 56px Segoe UI, Arial'; ctx.textBaseline = 'top'; ctx.fillStyle = '#fff'; ctx.strokeStyle = '#000'; ctx.lineWidth = 6;
    for (const k in G.texts) {
      const t = G.texts[k], s = String(G.vars[k] !== undefined ? G.vars[k] : 0), x = G.W / 2 + t.x, y = G.H / 2 - t.y;
      ctx.strokeText(s, x, y); ctx.fillText(s, x, y);
    }
  }

  // ---------- audio y video ----------
  function playSound(file, at) {
    if (!file) return null;
    let a = G.sounds[file];
    if (!a) { const p = findFile(file, G.sceneName); if (!p) { warn('Falta sonido: ' + file); return null; } a = new Audio(G.api.fileUrl(p)); G.sounds[file] = a; }
    a.onended = a.onerror = a.onpause = null;
    try { a.currentTime = at || 0; } catch {}
    a.play().catch(() => {}); return a;
  }
  function stopAllSounds() { for (const k in G.sounds) { const a = G.sounds[k]; a.onended = a.onerror = a.onpause = null; a.pause(); } G.sounds = {}; }
  function createVideo(b, sp) {
    const F = k => ev(b.f[k], sp), name = String(F('NAME')).trim(), file = String(F('FILE'));
    const old = G.videos[name]; if (old) { old.pause(); old.remove(); }
    const p = findFile(file, G.sceneName); if (!p) { warn('Falta video: ' + file); return; }
    const v = document.createElement('video'), w = num(F('WIDTH')), h = num(F('HEIGHT'));
    v.src = G.api.fileUrl(p); v.loop = truthy(F('LOOPED')); v.controls = truthy(F('CONTROLS')); v.playsInline = true; v.autoplay = true;
    Object.assign(v.style, { width: w + 'px', height: h + 'px', objectFit: 'fill', left: (G.W / 2 + num(F('POSX')) - w / 2) + 'px', top: (G.H / 2 - num(F('POSY')) - h / 2) + 'px' });
    document.getElementById('videos').appendChild(v); G.videos[name] = v; v.play().catch(() => {});
  }
  function clearMedia() {
    stopAllSounds();
    for (const k in G.videos) { G.videos[k].pause(); G.videos[k].remove(); } G.videos = {};
  }

  // ---------- escenas ----------
  function requestScene(name) { G.pending = name; for (const r of G.runs) r.dead = true; }
  function findScene(name) { return G.scenes.find(s => s.name === name) || G.scenes.find(s => s.name.trim() === String(name).trim()) || null; }
  async function loadScene(name) {
    const sc = findScene(name);
    if (!sc) { warn('Escena inexistente: ' + name); return; }
    G.loading = true; for (const r of G.runs) r.dead = true; G.runs.clear(); G.conds = []; G.texts = {}; clearMedia();
    if (!sc.compiled) sc.compiled = compScene(sc.el);
    G.sceneName = sc.name; G.sprites = sc.compiled.objs.map(od => makeSprite(od, sc.name));
    const jobs = [];
    for (const sp of G.sprites) for (const l of sp.looks) jobs.push(loadImg(l.file, sc.name).then(im => { l.img = im; }));
    await Promise.all(jobs);
    G.t0 = G.now; G.loading = false;
    for (const sp of G.sprites) for (const s of sp.scripts) {
      if (s.def.type === 'StartScript') startScript(s);
      else if (s.def.type === 'WhenConditionScript') G.conds.push(s);
    }
  }

  // ---------- bucle principal ----------
  function tick(ts) {
    G.now = ts; draw();
    if (G.pending !== null && !G.loading) { const n = G.pending; G.pending = null; loadScene(n); }
    else if (!G.loading) {
      for (const s of G.conds) { const v = truthy(ev(s.def.cond, s.sprite)); if (v && !s.prev) startScript(s); s.prev = v; }
    }
    if (G.touch.upReq) { G.touch.down = false; G.touch.upReq = false; }
    const due = [], rest = [];
    for (const w of G.waiters) (w.t <= G.now ? due : rest).push(w);
    G.waiters = rest; for (const w of due) w.res();
    requestAnimationFrame(tick);
  }
  function fit() {
    const wrap = document.getElementById('wrap'), s = Math.min(innerWidth / G.W, innerHeight / G.H);
    wrap.style.transform = 'translate(' + (innerWidth - G.W * s) / 2 + 'px,' + (innerHeight - G.H * s) / 2 + 'px) scale(' + s + ')';
  }
  function bindInput() {
    const wrap = document.getElementById('wrap');
    const pos = e => { const r = wrap.getBoundingClientRect(); G.touch.x = (e.clientX - r.left) / r.width * G.W - G.W / 2; G.touch.y = G.H / 2 - (e.clientY - r.top) / r.height * G.H; };
    wrap.addEventListener('pointerdown', e => { pos(e); G.touch.down = true; wrap.setPointerCapture(e.pointerId); if (!G.loading) tap(G.touch.x, G.touch.y); });
    wrap.addEventListener('pointermove', pos);
    const up = () => { G.touch.upReq = true; };
    wrap.addEventListener('pointerup', up); wrap.addEventListener('pointercancel', up);
  }

  async function start(src, api) {
    G.api = api; G.src = src;
    G.doc = new DOMParser().parseFromString(src.xml, 'text/xml');
    if (G.doc.querySelector('parsererror')) throw new Error('code.xml no es un XML válido');
    const header = G.doc.querySelector('header');
    G.W = parseInt(txt(header, 'virtualScreenWidth') || txt(header, 'screenWidth'), 10) || 2400;
    G.H = parseInt(txt(header, 'virtualScreenHeight') || txt(header, 'screenHeight'), 10) || 1080;
    document.title = txt(header, 'programName') || 'CatroPlayer';
    G.scenes = kids(kid(G.doc.documentElement, 'scenes'), 'scene').map(el => ({ name: txt(el, 'name') || txt(el, 'n'), el, compiled: null }));
    if (!G.scenes.length) throw new Error('El proyecto no tiene escenas');
    G.saved = (await api.loadVars()) || {};
    canvas = document.getElementById('c'); canvas.width = G.W; canvas.height = G.H; ctx = canvas.getContext('2d');
    const wrap = document.getElementById('wrap'); wrap.style.width = G.W + 'px'; wrap.style.height = G.H + 'px';
    const vids = document.getElementById('videos'); vids.style.width = G.W + 'px'; vids.style.height = G.H + 'px';
    addEventListener('resize', fit); fit(); bindInput();
    requestAnimationFrame(tick);
    await loadScene(G.scenes[0].name);
  }

  window.CatroEngine = { start, G, compScene, ev, hit, collides, collidesWithName, tap, exec };
})();
