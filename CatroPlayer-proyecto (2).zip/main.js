// Proceso principal de Electron: abre la ventana, elige el juego,
// descomprime .catrobat (una sola vez) e indexa los archivos de la carpeta.
const { app, BrowserWindow, dialog, ipcMain } = require('electron');
const path = require('path');
const fs = require('fs');
const extract = require('extract-zip');

// Misma carpeta de datos de siempre, aunque cambie el nombre del programa
app.setPath('userData', path.join(app.getPath('appData'), 'CatroPlayer'));

const TITLE = 'The presence: Slenderman';
let forceMenu = false;
let win;
let currentRoot = null, deviceFmt = 'map';
const logPath = () => path.join(app.getPath('userData'), 'registro.txt');

function createWindow() {
  win = new BrowserWindow({
    width: 1280, height: 600, backgroundColor: '#000000', autoHideMenuBar: true,
    title: TITLE, icon: path.join(__dirname, 'icon.png'),
    webPreferences: { autoplayPolicy: 'no-user-gesture-required', webSecurity: false, preload: path.join(__dirname, 'preload.js'), contextIsolation: true, sandbox: false }
  });
  win.on('page-title-updated', e => e.preventDefault()); // el título se queda fijo
  win.loadFile(path.join(__dirname, 'renderer', 'index.html'));
  win.webContents.on('before-input-event', (e, input) => {
    if (input.type === 'keyDown' && input.key === 'F11') win.setFullScreen(!win.isFullScreen());
    if (input.type === 'keyDown' && input.control && input.key.toLowerCase() === 'o') { forceMenu = true; win.reload(); } // abrir otro juego
    if (input.type === 'keyDown' && input.key === 'F12') win.webContents.toggleDevTools();
    if (input.type === 'keyDown' && input.key === 'Escape' && win.isFullScreen()) win.setFullScreen(false);
  });
}

// Carpeta junto al .exe (en modo portable, PORTABLE_EXECUTABLE_DIR apunta a donde está el .exe)
function exeDir() {
  return process.env.PORTABLE_EXECUTABLE_DIR || path.dirname(app.getPath('exe'));
}

const cfgPath = () => path.join(app.getPath('userData'), 'config.json');
function readCfg() { try { return JSON.parse(fs.readFileSync(cfgPath(), 'utf8')); } catch { return {}; } }
function writeCfg(o) { try { fs.writeFileSync(cfgPath(), JSON.stringify({ ...readCfg(), ...o })); } catch {} }

function findProjectRoot(dir) {
  // Busca la carpeta que contiene code.xml (en la raíz o a un nivel de profundidad)
  if (fs.existsSync(path.join(dir, 'code.xml'))) return dir;
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    if (e.isDirectory() && fs.existsSync(path.join(dir, e.name, 'code.xml'))) return path.join(dir, e.name);
  }
  return null;
}

function indexFiles(root) {
  const idx = {}; // nombre en minúsculas -> [rutas absolutas]
  (function walk(d) {
    for (const e of fs.readdirSync(d, { withFileTypes: true })) {
      const p = path.join(d, e.name);
      if (e.isDirectory()) walk(p);
      else (idx[e.name.toLowerCase()] ||= []).push(p);
    }
  })(root);
  return idx;
}

async function prepare(source) {
  let dir = source;
  if (fs.statSync(source).isFile()) {
    // .catrobat (zip): se descomprime una sola vez en la carpeta de datos del usuario
    const st = fs.statSync(source);
    const key = path.basename(source).replace(/[^\w.-]/g, '_') + '_' + st.size + '_' + Math.floor(st.mtimeMs);
    dir = path.join(app.getPath('userData'), 'games', key);
    if (!fs.existsSync(path.join(dir, '.listo'))) {
      fs.rmSync(dir, { recursive: true, force: true });
      fs.mkdirSync(dir, { recursive: true });
      let n = 0;
      await extract(source, { dir, onEntry: (entry, zip) => {
        if (++n % 25 === 0) win.webContents.send('progress', Math.round(n / zip.entryCount * 100));
      } });
      fs.writeFileSync(path.join(dir, '.listo'), '1');
    }
  }
  const root = findProjectRoot(dir);
  if (!root) throw new Error('No encontré code.xml en: ' + dir);
  writeCfg({ last: source, lastRoot: root });
  currentRoot = root;
  return { root, xml: fs.readFileSync(path.join(root, 'code.xml'), 'utf8'), index: indexFiles(root) };
}

ipcMain.handle('autoDetect', async () => {
  // Orden: 1) el último juego elegido (solo se elige una vez), 2) carpeta "juego" o .catrobat junto al .exe
  if (forceMenu) { forceMenu = false; return null; } // Ctrl+O: mostrar la pantalla de selección
  try {
    const c = readCfg();
    if (c.last && fs.existsSync(c.last)) return await prepare(c.last);
    if (c.lastRoot && fs.existsSync(path.join(c.lastRoot, 'code.xml'))) return await prepare(c.lastRoot);
    const base = exeDir(), juego = path.join(base, 'juego');
    if (fs.existsSync(juego) && findProjectRoot(juego)) return await prepare(juego);
    const f = fs.readdirSync(base).find(n => n.toLowerCase().endsWith('.catrobat'));
    if (f) return await prepare(path.join(base, f));
  } catch (e) { return { error: e.message }; }
  return null;
});

ipcMain.handle('pick', async (_e, kind) => {
  const r = kind === 'folder'
    ? await dialog.showOpenDialog(win, { properties: ['openDirectory'] })
    : await dialog.showOpenDialog(win, { properties: ['openFile'], filters: [{ name: 'Proyecto Catrobat', extensions: ['catrobat', 'zip'] }] });
  if (r.canceled || !r.filePaths[0]) return null;
  try { return await prepare(r.filePaths[0]); } catch (e) { return { error: e.message }; }
});

// Último juego abierto (para el botón "Continuar")
ipcMain.handle('lastGame', () => {
  const p = readCfg().last;
  return p && fs.existsSync(p) ? { path: p, name: path.basename(p) } : null;
});
ipcMain.handle('openPath', async (_e, p) => { try { return await prepare(p); } catch (e) { return { error: e.message }; } });

// Variables guardadas "en el dispositivo": se usa DeviceVariables.json dentro de la carpeta del juego
// (el mismo archivo que usa Pocket Code), así cada juego tiene su propio guardado.
const devPath = () => currentRoot ? path.join(currentRoot, 'DeviceVariables.json') : null;
ipcMain.handle('loadVars', () => {
  try {
    const j = JSON.parse(fs.readFileSync(devPath(), 'utf8'));
    if (Array.isArray(j)) { deviceFmt = 'array'; const o = {}; for (const e of j) if (e && e.name !== undefined) o[e.name] = e.value; return o; }
    deviceFmt = 'map'; return j && typeof j === 'object' ? j : {};
  } catch { return {}; }
});
ipcMain.handle('saveVars', (_e, obj) => {
  try {
    const out = deviceFmt === 'array' ? Object.keys(obj).map(k => ({ name: k, value: obj[k] })) : obj;
    fs.writeFileSync(devPath(), JSON.stringify(out)); return true;
  } catch (e) { return false; }
});
ipcMain.handle('log', (_e, line) => { try { fs.appendFileSync(logPath(), new Date().toISOString() + '  ' + line + '\n'); } catch {} });
ipcMain.handle('openUrl', (_e, url) => { if (/^https?:\/\//i.test(url)) require('electron').shell.openExternal(url); });
ipcMain.handle('quit', () => app.quit());

app.whenReady().then(createWindow);
app.on('window-all-closed', () => app.quit());
