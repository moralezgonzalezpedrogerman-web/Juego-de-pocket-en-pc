const { contextBridge, ipcRenderer } = require('electron');
const { pathToFileURL } = require('url');
contextBridge.exposeInMainWorld('api', {
  autoDetect: () => ipcRenderer.invoke('autoDetect'),
  pick: (kind) => ipcRenderer.invoke('pick', kind),
  loadVars: () => ipcRenderer.invoke('loadVars'),
  saveVars: (o) => ipcRenderer.invoke('saveVars', o),
  openPath: (p) => ipcRenderer.invoke('openPath', p),
  log: (t) => ipcRenderer.invoke('log', t),
  lastGame: () => ipcRenderer.invoke('lastGame'),
  openUrl: (u) => ipcRenderer.invoke('openUrl', u),
  quit: () => ipcRenderer.invoke('quit'),
  fileUrl: (p) => pathToFileURL(p).href,
  onProgress: (cb) => ipcRenderer.on('progress', (_e, v) => cb(v))
});
