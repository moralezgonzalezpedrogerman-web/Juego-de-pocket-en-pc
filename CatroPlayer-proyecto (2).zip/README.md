# The presence: Slenderman (Windows)

Reproductor de proyectos Pocket Code / Catrobat. Lee el `.catrobat` (o la carpeta ya descomprimida)
y ejecuta los bloques; no hay que convertir nada.

## Cómo se usa el .exe
El archivo se llama `The Presence - Slenderman.exe` (Windows no permite `:` en nombres de archivo).
La primera vez elige el `.catrobat` o la carpeta; el programa lo recuerda y las siguientes veces abre solo.
Ctrl+O = abrir otro juego. También funciona dejar junto al .exe, de cualquiera de estas formas:
- un archivo `.catrobat` en la misma carpeta (se descomprime solo la primera vez), o
- una carpeta llamada `juego` con `code.xml` y las carpetas de escenas dentro.

Si no encuentra nada, muestra botones para elegir el archivo o la carpeta.
F11 = pantalla completa.

## Compilar el .exe (3 opciones)
**A) En una PC con Windows:** instala Node.js (nodejs.org), abre una terminal en esta carpeta y ejecuta:

    npm install
    npm start          (para probarlo)
    npm run build      (genera dist/CatroPlayer.exe)

**B) Sin PC:** sube esta carpeta a un repositorio de GitHub; en la pestaña Actions ejecuta
"Compilar CatroPlayer.exe" y descarga el .exe como artefacto.

## Guardado y continuar
- Las variables "guardadas en el dispositivo" van en `DeviceVariables.json`, dentro de la carpeta del juego
  (el mismo archivo y formato de Pocket Code). Tu progreso guardado se conserva y cada juego tiene el suyo.
- Al abrir el reproductor aparece el botón **Continuar** con el último juego abierto.
- El "continuar" propio del juego (el del menú) lee ese archivo con el bloque "leer variable del dispositivo".

## Si algo falla
- **F12** abre la consola del desarrollador.
- Los avisos (imagen/sonido/video que falta, bloque no soportado, error de script) se guardan en
  `%APPDATA%\CatroPlayer\registro.txt`. Mándame su contenido para corregirlo.

## Notas
- Los archivos se buscan por nombre en todo el proyecto, dando prioridad a la carpeta de la escena.
- Vibración y sensores de móvil se ignoran. "Abrir URL" abre el navegador.
- Colisiones: objetos ocultos o 100 % transparentes no colisionan (como en Pocket Code).
- Toques: si el objeto de arriba no tiene bloque "al tocar", el toque pasa al de abajo.
- Suposición a confirmar: NativeViewConfigBrick con propiedad 1 se trata como opacidad del video.
