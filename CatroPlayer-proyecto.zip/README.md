# CatroPlayer (Windows)

Reproductor de proyectos Pocket Code / Catrobat. Lee el `.catrobat` (o la carpeta ya descomprimida)
y ejecuta los bloques; no hay que convertir nada.

## Cómo se usa el .exe
Pon `CatroPlayer.exe` junto a tu juego, de cualquiera de estas formas:
- un archivo `.catrobat` en la misma carpeta (se descomprime solo la primera vez), o
- una carpeta llamada `juego` con `code.xml` y las carpetas de escenas dentro.

Si no encuentra nada, muestra botones para elegir el archivo o la carpeta.
F11 = pantalla completa.

## Compilar el .exe (3 opciones)
**A) En una PC con Windows:** instala Node.js (nodejs.org), abre una terminal en esta carpeta y ejecuta:

    npm install
    npm start          (para probarlo)
    npm run build      (genera dist/CatroPlayer.exe)

**B) Sin PC:** sube esta carpeta a un repositorio de GitHub; en la pestaña Actions ejecuta
"Compilar CatroPlayer.exe" y descarga el .exe como artefacto.

## Notas
- Los archivos se buscan por nombre en todo el proyecto, dando prioridad a la carpeta de la escena.
- Variables guardadas en el dispositivo: se guardan en un archivo JSON en %APPDATA%/CatroPlayer.
- Vibración y sensores de móvil se ignoran. "Abrir URL" abre el navegador.
- Suposición a confirmar: NativeViewConfigBrick con propiedad 1 se trata como opacidad del video.
- Los bloques no soportados se avisan en consola (Ctrl+Shift+I no está habilitado; ver engine.js, `default:` de exec()).
